﻿SELECT name, mail
FROM userTbl
WHERE admin = 'false';