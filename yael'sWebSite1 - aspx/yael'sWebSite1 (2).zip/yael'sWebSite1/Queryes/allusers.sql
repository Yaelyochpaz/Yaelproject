﻿SELECT name, mail
FROM userTbl
